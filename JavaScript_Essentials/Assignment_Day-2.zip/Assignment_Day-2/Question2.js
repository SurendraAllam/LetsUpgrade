// Program to convert minutes to seconds

let num = prompt("Enter minutes: ");
console.log("Seconds: "+num*60);