function button1(){
    const i = document.getElementById("img");
    i.src = "img1.jpg"
}
function button2(){
    const i = document.getElementById("img");
    i.src = "img2.jpg"
}
function button3(){
    const i = document.getElementById("img");
    i.src = "img3.jpg"
}