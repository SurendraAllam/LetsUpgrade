function copyText(){
    const text = document.getElementsByClassName("input");
    text[1].value = text[0].value; 
}