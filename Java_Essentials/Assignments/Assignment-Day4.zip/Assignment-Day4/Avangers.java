/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;

/**
 *
 * @author Surendra
 */
public class Avangers {
        
        Scanner sc = new Scanner(System.in);
        
        String name,power,weapon,planet;
        int age;
        
        public void getDetails(){
            System.out.println("Enter name:");
            name=sc.nextLine();
            System.out.println("Enter age:");
            age=sc.nextInt();
            sc.nextLine();
            System.out.println("Enter power:");
            power=sc.nextLine();
            System.out.println("Enter weapon:");
            weapon=sc.nextLine();
            System.out.println("Enter planet:");
            planet=sc.next();
        }
        public void displayDetails(){
            System.out.println("The name is: "+name);
            System.out.println("The age is: "+age);
            System.out.println("The power is: "+power);
            System.out.println("The weapon is: "+weapon);
            System.out.println("The planet is: "+planet);
            System.out.println(" ");
        }
    
}
