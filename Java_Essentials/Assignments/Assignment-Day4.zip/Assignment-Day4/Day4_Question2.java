/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;

/**
 *
 * @author Surendra
 */
public class Day4_Question2 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int[] array = new int[5];
        System.out.println("Enter array numbers:");
        for(int i=0;i<5;i++){
            array[i]=sc.nextInt();
        }
        System.out.println("Print Odd numbers:");
        for(int i=0;i<5;i++){
            if(array[i]%2 == 1){
                System.out.println(array[i]);
            }
        }
        
    }
}
