/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;

/**
 *
 * @author Surendra
 */
public class Day4_Question1 {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        Avangers[] avanger = new Avangers[5];
        for(int i=0;i<5;i++){
            avanger[i] = new Avangers();
            avanger[i].getDetails();
        }
        System.out.println(" ");
        for(int i=0;i<5;i++){
            avanger[i].displayDetails();
        }
        
    }
}
