/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;

/**
 *
 * @author Surendra
 */
public class Game {
    Scanner sc=new Scanner(System.in);
    Question[] qArray = new Question[2];
    Player player = new Player();
    
    String[] questionsdata={"Int is a_?","What is the correct form of a method?"};
    String[] options1={"Dataype","getDetails[]"};
    String[] options2={"Variable","GETdetails{}"};
    String[] options3={"Access modifier","getDetails{}"};
    String[] options4={"Method","getDetails()"};
    int[] answers={1,4};

    public void initGame(){
        //sc.nextLine();
        for(int i=0;i<2;i++){
            qArray[i] = new Question();
        }
        for(int i=0;i<2;i++){
            qArray[i].qns = questionsdata[i];
            qArray[i].op1 = options1[i];
            qArray[i].op2 = options2[i];
            qArray[i].op3 = options3[i];
            qArray[i].op4 = options4[i];
            qArray[i].correctans = answers[i];
        }
        
    }
    public void play(){
          player.playerDetails();
          for(int i=0;i<2;i++){
              boolean status = qArray[i].askQuestion();
              if(status==true){
                  System.out.println("Heyy Your answer is correct..!!");
                  player.score++;
              }
              else{
                  System.out.println("Sorry your answer is wrong..!!");
                  //player.score--;
              }
          }
          
         System.out.println(player.name+" Your Score is: "+player.score);
    }
}
