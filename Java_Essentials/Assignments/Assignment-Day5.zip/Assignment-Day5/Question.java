/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;


/**
 *
 * @author Surendra
 */
public class Question {
    Scanner sc=new Scanner(System.in);
    String qns,op1,op2,op3,op4;
    int userans,correctans;
    public boolean askQuestion(){
        System.out.println(qns);
        System.out.println("1. "+op1);
        System.out.println("2. "+op2);
        System.out.println("3. "+op3);
        System.out.println("4. "+op4);
        System.out.println("Choose correct option:");
        userans=sc.nextInt();
        if(userans==correctans){
            return true;
        }
        return false;
    }
}