/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;

/**
 *
 * @author Surendra
 */
public class Day3_Question1 {
    public static void main(String[] args) {
        
        int phy,chem,maths,eng,it;
        float percentage,sum;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter Physics Marks:");
        phy = sc.nextInt();
        System.out.println("Enter Chemistry Marks:");
        chem = sc.nextInt();
        System.out.println("Enter Maths Marks:");
        maths = sc.nextInt();
        System.out.println("Enter English Marks:");
        eng = sc.nextInt();
        System.out.println("Enter IT Marks:");
        it = sc.nextInt();
        
        sum = (phy+chem+maths+eng+it);
        percentage = (sum/500)*100;
        
        if(percentage >= 70 && percentage <= 100){
            System.out.println("Your Grade is 'A'");
        }
        else if(percentage >= 50 && percentage < 70){
            System.out.println("Your Grade is 'B'");
        }
        else if(percentage >= 35 && percentage < 50){
            System.out.println("Your Grade is 'C'");
        }
        else{
            System.out.println("Your Failed");
        }
    }
}
