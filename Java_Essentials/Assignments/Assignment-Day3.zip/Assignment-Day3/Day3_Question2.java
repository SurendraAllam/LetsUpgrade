/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letsupgrade;

import java.util.Scanner;

/**
 *
 * @author Surendra
 */
public class Day3_Question2 {
    public static void main(String[] args) {
        
        String name;
        float monthly_salary,annual_salary,tax_amount=0;
        int day,month,year,age;
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter Employee Name:");
        name = sc.next();
        
        System.out.println("Enter Employee Monthly Salary:");
        monthly_salary = sc.nextFloat();
        
        annual_salary = monthly_salary*12;
        
        float num1,num2=100;
        if(annual_salary>=500000){
            num1 = 20;
            tax_amount = annual_salary*(num1/num2);
        }
        else if(annual_salary>=400000&&annual_salary<500000){
            num1 = 15;
            tax_amount = annual_salary*(num1/num2);
        }
        else if(annual_salary>=300000&&annual_salary<400000){
            num1 = 10;
            tax_amount = annual_salary*(num1/num2);
        }
        else{
            num1 = 5;
            tax_amount = annual_salary*(num1/num2);
        }
        
        System.out.println("Enter Employee Date of birth:");
        day = sc.nextInt();
        System.out.println("Enter Employee Date of month:");
        month = sc.nextInt();
        System.out.println("Enter Employee Date of year:");
        year = sc.nextInt();
        
        age = 2020 - year;
        
        System.out.println("Employee Name: "+name);
        System.out.println("Employe Age: "+age);
        System.out.println("Employee Annual Salary: "+annual_salary);
        System.out.println("Employee Tax Amount: "+tax_amount);
        
    }
}
